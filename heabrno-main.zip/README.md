index.html (main page)

team.html (team page)

outreach.html (outreach page)

people/*.html (team page)

